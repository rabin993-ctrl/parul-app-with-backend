# 05 — Flutter App Architecture & Integration

> How the Flutter client is structured and wired to the backend ([`02`](02-data-model.md) /
> [`03`](03-api-reference.md) / [`04`](04-realtime-and-notifications.md)). The current Expo/React
> Native app is the **design reference**; this is the equivalent Flutter build.

## 1. App structure (feature-first)

Mirror the backend modules so the team can talk about "the adoption feature" end-to-end.

```
lib/
  main.dart
  app.dart                     // MaterialApp.router, theme, providers
  core/
    api/                       // generated OpenAPI client + Dio config
    realtime/                  // WebSocket client, channel manager
    auth/                      // token store, refresh interceptor, session
    theme/                     // colors, typography (light/dark), tokens
    storage/                   // secure storage, cache (Hive/Isar)
    error/                     // failure types, error mapping
    widgets/                   // shared UI (Avatar, Badge, Sheet, Empty, Toast, Segmented)
  features/
    identity/                  // auth screens, profile, privacy, blocking, reviews
    companions/
    feed/
    community/
    circles/
    adoption/
    rescue/
    messaging/
    vet/
    treats/
    notifications/
      <feature>/
        data/                  // repository, dtos, mappers
        domain/                // entities, use-cases (optional)
        presentation/          // screens, widgets, state (riverpod/bloc)
```

## 2. Recommended packages

| Concern | Package | Notes |
|---------|---------|-------|
| HTTP | `dio` | interceptors for auth, retry, logging |
| API client | `openapi-generator` (dart-dio) | generate from the OpenAPI spec in [`03`](03-api-reference.md) |
| State mgmt | `flutter_riverpod` (or `flutter_bloc`) | one consistent choice; Riverpod suits this app's many contexts |
| Routing | `go_router` | maps to the 5-tab shell + stacked flows; deep links for push |
| Realtime | `web_socket_channel` | wrap in a channel manager (see §5) |
| Local cache / offline | `isar` or `hive` | cache feed, threads, profile for instant cold start |
| Secure tokens | `flutter_secure_storage` | access/refresh tokens |
| Auth helpers | `firebase_auth` / `google_sign_in` / `sign_in_with_apple` | if using OAuth/phone OTP via Firebase |
| Push | `firebase_messaging` | FCM tokens → `POST /me/push-tokens` |
| Payments | `razorpay_flutter` | vet consult checkout (UPI/card/wallet) |
| Media | `image_picker`, `video_player`, `cached_network_image` | composer + galleries |
| Models | `freezed` + `json_serializable` | immutable DTOs/entities |
| Forms/validation | `reactive_forms` or manual | composer/listing forms |

## 3. Navigation shell (maps to the prototype)

A `StatefulShellRoute` (go_router) with the **5 bottom tabs** the app already uses:

```
/feed        (+ in-app Home Hub: Feed | Community | Adoption; Rescue as a stacked flow)
/messages    -> /messages/thread/:id
/circles     -> /circles/explore, /circles/:id (chat), /:id/members, /:id/settings, /:id/admin
/vet         -> urgent flow (issue→pet→symptoms→matching→assigned→payment→session), browse, history
/profile     -> settings, privacy, blocked, activity, saved, posts, rescues, adopted, reviews
```

Stacked/global flows: adoption (listing/detail/create/edit/manage/confirm), rescue (open
case/update), community (group/create/admin/requests), companion profile modal. Push deep-links
resolve `entity_type` + `entity_id` ([`04`](04-realtime-and-notifications.md) §4) to a route.

## 4. Data layer pattern

Per feature: **Repository** ← **Remote data source (API)** + **Local cache**.

```dart
// adoption/data/adoption_repository.dart
class AdoptionRepository {
  final ParulApi api;          // generated client
  final AdoptionCache cache;   // isar/hive

  Future<List<AdoptionListing>> browse(AdoptionFilters f) async {
    final res = await api.getAdoptions(/* filters */);
    final items = res.data.map(AdoptionListing.fromDto).toList();
    await cache.putListings(items);
    return items;
  }

  Future<AdoptionRequest> requestAdoption(String listingId, String message) =>
      api.createAdoptionRequest(listingId, body: {'message': message})
         .then(AdoptionRequest.fromDto);
}
```

DTOs (`freezed`) match the JSON in [`03`](03-api-reference.md); domain entities match the field names
in [`02`](02-data-model.md). Display strings ("2 days ago") are derived in the presentation layer
from real `timestamptz` via `timeago` or a custom formatter.

## 5. Realtime channel manager

A singleton that owns the socket, multiplexes channel subscriptions, and exposes per-channel streams
that feature controllers listen to:

```dart
final manager = RealtimeManager(tokenProvider: auth.accessToken);
manager.subscribe('thread:$threadId');
manager.events
  .where((e) => e.channel == 'thread:$threadId')
  .listen(chatController.onEvent);   // message.created, typing, read, ...
```

Reconnect with backoff, resubscribe active channels, and on resume re-fetch via REST to close gaps
(see [`04`](04-realtime-and-notifications.md) §5).

## 6. Auth & token lifecycle

- Store access + refresh in `flutter_secure_storage`.
- `Dio` interceptor: attach `Authorization`; on `401`, call `/auth/refresh` once, retry, else route
  to login.
- On login, register the FCM token (`POST /me/push-tokens`); on logout, unregister + revoke session.

## 7. Theming

The prototype ships a full light/dark theme with design tokens and the Source Sans 3 font. Recreate
as a Flutter `ThemeData` pair (light/dark) plus a token file (colors, radii, spacing) under
`core/theme/`. Keep the tab bar's frosted/glass treatment via `BackdropFilter`.

## 8. Offline & optimistic UX

- **Optimistic writes** for paw/save/comment/message with rollback on failure.
- **Cache-first reads** for feed, threads, profile, companions → instant cold start, then refresh.
- **Idempotency-Key** on message/payment sends to dedupe retries.
- Queue composer submissions when offline; flush on reconnect.

## 9. Build/release notes

- Flavors: `dev` / `staging` / `prod` with per-env base URL + Razorpay/Firebase keys.
- Generate the API client in CI whenever the OpenAPI spec changes (contract stays in sync).
- Crash/error reporting via Sentry; analytics events on the key funnels (request→approve→confirm,
  consult→pay→session).
